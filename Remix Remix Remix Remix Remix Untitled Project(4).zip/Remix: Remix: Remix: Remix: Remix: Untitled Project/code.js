var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["e9323b8b-c218-42db-b14c-fba9f18b2eb9","0a1f6c7b-9147-4580-b9cc-e5237ddda182","9b944fb5-1467-4ac5-bb45-2e48e30b674a","3cec7259-df0a-4f95-90f7-696e8dfb4878","02c0c60d-eac7-4481-a613-ad4b3d105d1f","326a91d6-2e9e-4871-8aaa-5cddd5582fc3","853cd782-7f27-47db-8f01-2ddb91e09616","d700317a-e5b0-41ba-89ac-c2c402708c3b","3644e520-f0fd-45f7-afb8-f16054b4a63a","464385b9-e1e5-43de-9976-ba8fe7693189"],"propsByKey":{"e9323b8b-c218-42db-b14c-fba9f18b2eb9":{"name":"kid_30_1","sourceUrl":null,"frameSize":{"x":235,"y":341},"frameCount":1,"looping":true,"frameDelay":12,"version":"g80UAY3DA3p_Gdo5V7i02BwxapvC0wYq","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":235,"y":341},"rootRelativePath":"assets/e9323b8b-c218-42db-b14c-fba9f18b2eb9.png"},"0a1f6c7b-9147-4580-b9cc-e5237ddda182":{"name":"kid_7_1","sourceUrl":"assets/api/v1/animation-library/gamelab/ad7BJVmq4MSL6Gamakv8PIPvptUFuNwG/category_people/kid_7.png","frameSize":{"x":291,"y":415},"frameCount":1,"looping":true,"frameDelay":2,"version":"ad7BJVmq4MSL6Gamakv8PIPvptUFuNwG","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":291,"y":415},"rootRelativePath":"assets/api/v1/animation-library/gamelab/ad7BJVmq4MSL6Gamakv8PIPvptUFuNwG/category_people/kid_7.png"},"9b944fb5-1467-4ac5-bb45-2e48e30b674a":{"name":"santa_1","sourceUrl":"assets/api/v1/animation-library/gamelab/9ZleRnJkMxYhfpPY2zZrrikGdZ6H6F6l/category_backgrounds/background_santa.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"9ZleRnJkMxYhfpPY2zZrrikGdZ6H6F6l","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/9ZleRnJkMxYhfpPY2zZrrikGdZ6H6F6l/category_backgrounds/background_santa.png"},"3cec7259-df0a-4f95-90f7-696e8dfb4878":{"name":"virus03_11_1","sourceUrl":"assets/api/v1/animation-library/gamelab/dHshQXiche2omlBhwWrKH5zbfEiC6doy/category_germs/virus03_11.png","frameSize":{"x":390,"y":390},"frameCount":1,"looping":true,"frameDelay":2,"version":"dHshQXiche2omlBhwWrKH5zbfEiC6doy","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":390},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dHshQXiche2omlBhwWrKH5zbfEiC6doy/category_germs/virus03_11.png"},"02c0c60d-eac7-4481-a613-ad4b3d105d1f":{"name":"virus03_04_1","sourceUrl":"assets/api/v1/animation-library/gamelab/7_fQFvQ9YjMoziYN80X0zhQJiJXHDA.t/category_germs/virus03_04.png","frameSize":{"x":390,"y":390},"frameCount":1,"looping":true,"frameDelay":2,"version":"7_fQFvQ9YjMoziYN80X0zhQJiJXHDA.t","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":390},"rootRelativePath":"assets/api/v1/animation-library/gamelab/7_fQFvQ9YjMoziYN80X0zhQJiJXHDA.t/category_germs/virus03_04.png"},"326a91d6-2e9e-4871-8aaa-5cddd5582fc3":{"name":"gameplaywacky_05_1","sourceUrl":"assets/api/v1/animation-library/gamelab/ZdtNFtOiydwR9zKYWovoGTaaRFuvBF6p/category_germs/gameplaywacky_05.png","frameSize":{"x":397,"y":372},"frameCount":1,"looping":true,"frameDelay":2,"version":"ZdtNFtOiydwR9zKYWovoGTaaRFuvBF6p","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":397,"y":372},"rootRelativePath":"assets/api/v1/animation-library/gamelab/ZdtNFtOiydwR9zKYWovoGTaaRFuvBF6p/category_germs/gameplaywacky_05.png"},"853cd782-7f27-47db-8f01-2ddb91e09616":{"name":"gameplaywacky_04_1","sourceUrl":"assets/api/v1/animation-library/gamelab/6RErheXohDYDqsju4kZuQxK7OYey6QJn/category_germs/gameplaywacky_04.png","frameSize":{"x":391,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"6RErheXohDYDqsju4kZuQxK7OYey6QJn","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":391,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/6RErheXohDYDqsju4kZuQxK7OYey6QJn/category_germs/gameplaywacky_04.png"},"d700317a-e5b0-41ba-89ac-c2c402708c3b":{"name":"retro_coin_1","sourceUrl":"assets/api/v1/animation-library/gamelab/yyMkmGM.lMnt0PF6R49LlyGX9vMPtDav/category_retro/retro_coin.png","frameSize":{"x":95,"y":113},"frameCount":1,"looping":true,"frameDelay":2,"version":"yyMkmGM.lMnt0PF6R49LlyGX9vMPtDav","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":95,"y":113},"rootRelativePath":"assets/api/v1/animation-library/gamelab/yyMkmGM.lMnt0PF6R49LlyGX9vMPtDav/category_retro/retro_coin.png"},"3644e520-f0fd-45f7-afb8-f16054b4a63a":{"name":"space_1","sourceUrl":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png"},"464385b9-e1e5-43de-9976-ba8fe7693189":{"name":"cupcake_1","sourceUrl":"assets/api/v1/animation-library/gamelab/VFvAjZCeLHhB39GafnRGfnrQhYdWk1xY/category_food/cupcake.png","frameSize":{"x":283,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"VFvAjZCeLHhB39GafnRGfnrQhYdWk1xY","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":283,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/VFvAjZCeLHhB39GafnRGfnrQhYdWk1xY/category_food/cupcake.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var back = createSprite(200, 200);
var boy = createSprite(30, 365, 10, 10);
back.setAnimation("santa_1");
boy.setAnimation("kid_7_1");
boy.height = 35;
boy.width = 25;
var coin = createSprite(365, 375, 10, 10);
coin.setAnimation("retro_coin_1");
coin.height = 20;
coin.width = 20;
var wall1
var wall1 = createSprite(10, 70, 100, 20);
wall1.shapeColor = "green";
var wall2
var wall2 = createSprite(100, 50, 20, 100);
wall2.shapeColor = "blue";
var wall3;
var wall3 = createSprite(50, 180, 20, 100);
wall3.shapeColor = "red";
var wall4;
var wall4 = createSprite(10, 200, 100, 20);
wall4.shapeColor = "yellow";
var wall5;
var wall5 = createSprite(160, 50, 20, 100);
wall5.shapeColor = "green";
var wall6;
var wall6 = createSprite(260, 90, 100, 20);
wall6.shapeColor = "blue";
var wall7;
var wall7 = createSprite(260, 40, 100, 20);
wall7.shapeColor = "red";
var wall8;
var wall8 = createSprite(300, 25, 20, 50);
wall8.shapeColor = "yellow";
var wall9;
var wall9 = createSprite(300, 130, 20, 100);
wall9.shapeColor = "green";
var wall10;
var wall10 = createSprite(160, 200, 140, 20);
wall10.shapeColor = "blue";
var wall11;
var wall11 = createSprite(140, 150, 100, 20);
wall11.shapeColor = "red";
var wall12;
var wall12 = createSprite(230, 190, 20, 100);
wall12.shapeColor = "yellow";
var wall13;
var wall13 = createSprite(310, 40, 100, 20);
wall13.shapeColor = "green";
var wall14;
var wall14 = createSprite(100, 250, 20, 200);
wall14.shapeColor = "blue";
var wall15;
var wall15 = createSprite(10, 270, 100, 20);
wall15.shapeColor = "red";
var wall16;
var wall16 = createSprite(155, 330, 20, 140);
wall16.shapeColor = "yellow";
var wall17;
var wall17 = createSprite(230, 320, 20, 160);
wall17.shapeColor = "green";
var wall18;
var wall18 = createSprite(350, 170, 20, 180);
wall18.shapeColor = "blue";
var wall19;
var wall19 = createSprite(315, 305, 85, 20);
wall19.shapeColor = "red";
var wall20;
var wall20 = createSprite(320, 350, 20, 100);
wall20.shapeColor = "yellow";
var wall21;
var wall21 = createSprite(10, 340, 100, 20);
wall21.shapeColor = "green";
var wall22;
var wall22 = createSprite(370, 160, 60, 20);
wall22.shapeColor = "blue";
function draw() {
  background("white");
  drawSprites();
  createEdgeSprites();
  if (keyDown(RIGHT_ARROW)) {
    boy.velocityX = 3;
    boy.velocityY = 0;
  }
  if (keyDown(LEFT_ARROW)) {
    boy.velocityX = -3;
    boy.velocityY = 0;
  }
  if (keyDown(UP_ARROW)) {
    boy.velocityX = 0;
    boy.velocityY = -3;
  }
  if (keyDown(DOWN_ARROW)) {
    boy.velocityX = 0;
    boy.velocityY = 3;
  }
  if (boy.isTouching(coin)) {
   wall1.destroy();
   wall2.destroy();
   wall3.destroy();
   wall4.destroy();
   wall5.destroy();
   wall6.destroy();
   wall7.destroy();
   wall8.destroy();
   wall9.destroy();
   wall10.destroy();
   wall11.destroy();
   wall12.destroy();
   wall13.destroy();
   wall14.destroy();
   wall15.destroy();
   wall16.destroy();
   wall17.destroy();
   wall18.destroy();
   wall19.destroy();
   wall20.destroy();
   wall21.destroy();
   wall22.destroy();
   coin.destroy();
   boy.destroy();
   back.destroy();

  }
  boy.bounceOff(edges);
  boy.bounceOff(wall1);
boy.bounceOff(wall2);
boy.bounceOff(wall3);
boy.bounceOff(wall4);
boy.bounceOff(wall5);
boy.bounceOff(wall6);
boy.bounceOff(wall7);
boy.bounceOff(wall8);
boy.bounceOff(wall9);
boy.bounceOff(wall10);
boy.bounceOff(wall11);
boy.bounceOff(wall12);
boy.bounceOff(wall13);
boy.bounceOff(wall14);
boy.bounceOff(wall15);
boy.bounceOff(wall16);
boy.bounceOff(wall17);
boy.bounceOff(wall18);
boy.bounceOff(wall19);
boy.bounceOff(wall20);
boy.bounceOff(wall21);
boy.bounceOff(wall22);
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
